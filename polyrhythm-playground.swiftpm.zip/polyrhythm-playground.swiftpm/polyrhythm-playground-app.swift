import SwiftUI

@main
struct PolyrhythmPlaygroundApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
